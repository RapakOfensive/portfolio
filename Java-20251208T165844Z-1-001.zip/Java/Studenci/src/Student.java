public class Student {
    static int liczbaStudentow = 0;
    String imie;
    String nazwisko;
    int indeks;

    public Student(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.indeks = 1000;
        liczbaStudentow++;
    }

    public String full(){
        return (imie + " " + nazwisko + ", " + indeks);
    }
    public String dane(){
        return(imie + " "+ nazwisko);
    }
    public String index(){
        return (indeks+ "");
    }
    public String zmiana_index(int nowyindex){
        this.indeks = nowyindex;
        return ("Index bedzie wynosil: "+ indeks);
    }
}