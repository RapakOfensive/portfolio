public class Main {
    public static void main(String[] args) {

        Student student1 = new Student("Jan", "Kowalski");
        Student student2 = new Student("Anna", "Nowak");

        System.out.println(student1.full() + " " + student1.dane());
        System.out.println(student2.full() + " " + student2.dane());
        System.out.println(student1.zmiana_index(1002));
        System.out.println(Student.liczbaStudentow);
    }
}
