public class samochody{
    String nazwa;
    int pasazerowie;
    int pojemnosc;
    double spalanie;

    public Samochod(String nazwa, int pasazerowie, int pojemnosc, double spalanie) {
        this.nazwa = nazwa;
        this.pasazerowie = pasazerowie;
        this.pojemnosc = pojemnosc;
        this.spalanie = spalanie;
    }

    public double obliczZasieg() {
        return (pojemnosc / spalanie) * 100;
    }

    public double obliczPaliwoNaKilometry(double iloscKilometrow) {
        return (iloscKilometrow * spalanie) / 100;
    }
}
