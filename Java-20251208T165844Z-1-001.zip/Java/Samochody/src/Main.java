public class Main {
    public static void main(String[] args) {
        samochody Samochod = new samochody.Samochod("Toyota Corolla", 5, 15, 7.5);

        System.out.printf("%s może mieścić %d pasażerów.\n", Samochod.nazwa, Samochod.pasazerowie);
        System.out.printf("Ma pojemność %d litrów, a spalanie %.1f litrów na 100 km,\n", Samochod.pojemnosc, Samochod.spalanie);
        double zasieg = Samochod.obliczZasieg();
        System.out.printf("dzięki czemu można nim przejechać %.0f km.\n", zasieg);
        double paliwoNa200km = Samochod.obliczPaliwoNaKilometry(200);
        System.out.printf("Ilość paliwa potrzebna na 200 km: %.2f litrów\n", paliwoNa200km);
    }
}
