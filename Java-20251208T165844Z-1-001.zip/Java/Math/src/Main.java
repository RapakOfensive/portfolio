import java.lang.Math;
import java.math.BigInteger;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        double x = Math.PI;
//        System.out.println("Hello world!");
//        System.out.printf("Liczba PI: %.5f\n", x);
//        System.out.printf("Pierwiastek kwadratowy: %.5f\n", Math.sqrt(x));
//        System.out.printf("Pierwiastek sześcienny: %.5f\n", Math.cbrt(x));
//        System.out.printf("Zaokrąglenie w górę:  %.1f\n", Math.ceil(x));
//        System.out.printf("Zaokrąglanie w dół: %.1f\n", Math.floor(x));
//        System.out.printf("Zaokrąglenie do całkowitej: %f\n", Math.rint(x));
//        float a = 4;
//        float b = 5;
//        System.out.printf("Przeciwprostokątna trójkąta o bokach %.1f %.1f = %.5f\n", a, b, Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2)));
//        int y = 9;
//        int z = 8;
//        System.out.println("Zmienna a:" + z);
//        System.out.println("Zmienna b:" + y);
//        System.out.println("Wynik mnożenia: "+ z*y);
//        double w = Math.divideExact(z, y);
//        System.out.println("Wynik dzielenia: "+ w);
//        System.out.println("Wynik dodawania: "+ z+y);
//        double v = Math.pow((5280*12), 3);
//        System.out.println("Mila sześcienna zawiera " + v + "cali sześciennych");
//        char zmienna = 'D';
//        System.out.println(zmienna);
//        zmienna++;
//        System.out.println(zmienna);
//        zmienna = 90;
//        System.out.println(zmienna);
//        int c = 37;
//        int d = 11;
//        int w_dzielenia = c/d;
//        int reszta = c%d;
//        System.out.println(w_dzielenia);
//        System.out.println(reszta);
//        System.out.printf("%-10s %-10s %-10s %-10s %-10s%n", "A", "B", "A && B", "A || B", "!A");
//        System.out.println("-----------------------------------------------");
//
//        boolean[] values = {false, true};
//
//        for (boolean e : values) {
//            for (boolean f : values) {
//                boolean andResult = e && f;
//                boolean orResult = e || f;
//                boolean notA = !e;
//
//                System.out.printf("%-10s %-10s %-10s %-10s %-10s%n", e, f, andResult, orResult, notA);
//            }
//        }
//        System.out.print("Wprowadź znak: ");
//        try {
//            char znak = (char) System.in.read();
//            System.out.print("Wprowadzony znak: " + znak);
//        } catch (IOException e) {
//            System.out.println("Wystąpił błąd podczas wczytywania znaku.");
//        }
        Scanner scanner = new Scanner(System.in);

        System.out.print("Wprowadź liczbę x: ");
        float x = scanner.nextFloat();
        System.out.print("Wprowadź liczbę y: ");
        float y = scanner.nextFloat();

        float suma = x + y;
        float roznica = x - y;
        float iloczyn = x * y;
        float iloraz = y != 0 ? x / y : Float.NaN;

        System.out.printf("Suma: %.2f%n", suma);
        System.out.printf("Różnica: %.2f%n", roznica);
        System.out.printf("Iloczyn: %.2f%n", iloczyn);
        if (y != 0) {
            System.out.printf("Iloraz: %.2f%n", iloraz);
        } else {
            System.out.println("Iloraz: nieokreślony (dzielenie przez zero)");
        }

        scanner.close();
    }
}