public class Main {
    public static void main(String[] args) {
        Rower row1 = new Rower(5, 10);
        Rower row2 = new Rower(10, 5);
        System.out.println(Rower.ile);
        row1.start();
        row2.stop();
        row1.opis();
    }
}