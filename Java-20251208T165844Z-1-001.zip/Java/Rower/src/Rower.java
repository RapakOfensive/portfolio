public class Rower {
    int szybkosc;
    int rozmiar_kola;
    static int ile;
    Rower(int v, int r){
        this.szybkosc=v;
        this.rozmiar_kola=r;
        ile++;
    }
    void start(){
        szybkosc++;
        System.out.println("Rower przyspieszył. Prędkość bieżąca: "+ szybkosc);
    }
    void stop(){
        szybkosc--;
        System.out.println("Rower zwolnił. Prędkość bieżąca: "+ szybkosc);
    }
    void opis(){
        System.out.println("Rower leci z prędkością "+ szybkosc+ ", jego koło ma rozmiar "+rozmiar_kola);
    }
}
