public class Main{
    public static void main(String[] args) {
        int[][] passengers = new int[7][];
        for (int day = 0; day < 7; day++) {
            if (day < 5) {
                passengers[day] = new int[10];
            } else {
                passengers[day] = new int[2];
            }
        }
        for (int day = 0; day < passengers.length; day++) {
            for (int course = 0; course < passengers[day].length; course++) {
                passengers[day][course] = (int) (Math.random() * 50);
            }
        }

        System.out.println("Liczba pasażerów w tygodniu:");
        for (int day = 0; day < 5; day++){
            for (int course = 0; course < passengers[day].length; course++) {
                System.out.print(passengers[day][course] + " ");
            }
            System.out.println();
        }

        System.out.println("\nLiczba pasażerów w weekend:");
        for (int day = 5; day < 7; day++){
            for (int course = 0; course < passengers[day].length; course++) {
                System.out.print(passengers[day][course] + " ");
            }
            System.out.println();
        }
    }
}