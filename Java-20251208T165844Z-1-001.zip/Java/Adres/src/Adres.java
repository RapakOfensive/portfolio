public class Adres{
    String miejscowosc;
    String kodPocztowy;
    String nazwaUlicy;
    int nrDomu;
    Adres(String s, String k, String n, int nr){
        this.miejscowosc = s;
        this.kodPocztowy=k;
        this.nazwaUlicy=n;
        this.nrDomu=nr;
    }
    Adres(String s, String k, int nr){
        this.miejscowosc=s;
        this.kodPocztowy=k;
        this.nrDomu=nr;
    }
    public Adres() {
        this("Wieprzec", "34-231", "Wieprzowiecka", 19);
    }
    void setMiejscowosc(String m){
        this.miejscowosc="Sezamkowo";
        this.miejscowosc=m;
    }
    void setKodPocztowy(String k){
        this.kodPocztowy="34-210";
        this.kodPocztowy=k;
    }
    void setNazwaUlicy(String n){
        this.nazwaUlicy="Sezamkowa";
        this.nazwaUlicy=n;
    }
    void setNrDomu(int n){
        this.nrDomu=27;
        this.nrDomu=n;
    }
    void opis(){
        System.out.println("Zamieszkuje "+this.miejscowosc+" \nz kodem pocztowym "+this.kodPocztowy+" \nna dokładnej ulicy "+this.nazwaUlicy+" \no dokładnym numerze domu "+this.nrDomu+". \nNigdy jednak nie ujawniłem swojej osoby ani swojego adresu, nikt zupełnie o tym nie wiedział, jednak ryzyko sytuacji tego wymaga, żegnaj więc drogi zbawicielu.");
    }
}